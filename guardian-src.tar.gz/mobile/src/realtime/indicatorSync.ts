/**
 * Keeps the Android foreground notification in step with real stream state.
 *
 * Subscribes to the store rather than being called from components, so no
 * screen can forget to update it - and no screen can choose not to.
 */

import { ForegroundService, type ServiceState } from '../native/ForegroundService';
import { shouldShareLocation } from '../store/reconcile';
import type { RootState } from '../store';

function derive(state: RootState): ServiceState {
  const sharingLocation = Object.values(state.connection.snapshots).some((s) =>
    shouldShareLocation(s ?? null),
  );
  return {
    sharingLocation,
    cameraLive: state.stream.active.some((s) => s.kind === 'CAMERA'),
    microphoneLive: state.stream.active.some((s) => s.kind === 'MICROPHONE'),
  };
}

function same(a: ServiceState, b: ServiceState): boolean {
  return (
    a.sharingLocation === b.sharingLocation &&
    a.cameraLive === b.cameraLive &&
    a.microphoneLive === b.microphoneLive
  );
}

export function createIndicatorSync(getState: () => RootState): () => void {
  let last: ServiceState | null = null;
  let running = false;

  return () => {
    const next = derive(getState());
    if (last && same(last, next)) return;
    last = next;

    const anythingActive = next.sharingLocation || next.cameraLive || next.microphoneLive;

    if (!anythingActive) {
      if (running) {
        running = false;
        void ForegroundService.stop();
      }
      return;
    }

    if (!running) {
      running = true;
      void ForegroundService.start(next);
    } else {
      void ForegroundService.update(next);
    }
  };
}

export { derive as deriveServiceState };
