/**
 * Socket.io client.
 *
 * Two responsibilities that mirror the server (server/src/realtime/io.ts):
 *   - receive `privacy:state` and treat it as authoritative;
 *   - receive `command:sensor` and raise the indicator before capture starts.
 *
 * The server has already run the privacy gate before any command reaches us.
 * We re-check locally anyway: cheap, and it means a compromised or buggy
 * server still cannot start a stream the user has switched off.
 */

import { io, type Socket } from 'socket.io-client';
import { API_BASE_URL } from '../config';
import type { PrivacyChannel, PrivacySnapshot } from '../api/types';
import { shouldShareLocation } from '../store/reconcile';

export interface SensorCommand {
  pairingId: string;
  kind: 'CAMERA' | 'MICROPHONE';
  requestedAt: string;
  requiresIndicator: boolean;
}

export interface SocketHandlers {
  onPrivacyState(pairingId: string, snapshot: PrivacySnapshot): void;
  onSensorCommand(command: SensorCommand): void;
  onConnectionChange(connected: boolean): void;
  /** Local snapshot lookup, used for the defence-in-depth re-check. */
  getSnapshot(pairingId: string): PrivacySnapshot | null;
  /** Called when a command was refused locally despite server approval. */
  onLocalRefusal(command: SensorCommand, reason: string): void;
}

let socket: Socket | null = null;

function localChannelAllows(snapshot: PrivacySnapshot | null, channel: PrivacyChannel): boolean {
  if (!snapshot) return false;
  if (snapshot.pairingStatus !== 'ACTIVE') return false;
  if (snapshot.tier === 'GUARDIAN_MANAGED' && snapshot.guardianLockedChannels.includes(channel)) {
    return true;
  }
  if (snapshot.masterShieldActive) return false;
  return channel === 'CAMERA' ? snapshot.cameraEnabled : snapshot.microphoneEnabled;
}

export function connectSocket(accessToken: string, handlers: SocketHandlers): Socket {
  disconnectSocket();

  socket = io(API_BASE_URL, {
    auth: { token: accessToken },
    transports: ['websocket'],
    reconnection: true,
    reconnectionDelay: 1_000,
    reconnectionDelayMax: 10_000,
  });

  socket.on('connect', () => handlers.onConnectionChange(true));
  socket.on('disconnect', () => handlers.onConnectionChange(false));

  socket.on('privacy:state', (payload: { pairingId: string; snapshot: PrivacySnapshot }) => {
    if (payload?.pairingId && payload.snapshot) {
      handlers.onPrivacyState(payload.pairingId, payload.snapshot);
    }
  });

  socket.on('command:sensor', (command: SensorCommand) => {
    if (!command?.pairingId || !command.kind) return;

    const snapshot = handlers.getSnapshot(command.pairingId);
    if (!localChannelAllows(snapshot, command.kind)) {
      handlers.onLocalRefusal(command, 'LOCAL_STATE_DENIES');
      return;
    }
    handlers.onSensorCommand(command);
  });

  return socket;
}

export function subscribeToPairing(pairingId: string): Promise<PrivacySnapshot | null> {
  return new Promise((resolve) => {
    if (!socket) {
      resolve(null);
      return;
    }
    socket.emit('pairing:subscribe', { pairingId }, (res: unknown) => {
      const ok = (res as { ok?: boolean; privacy?: PrivacySnapshot })?.ok;
      resolve(ok ? ((res as { privacy: PrivacySnapshot }).privacy ?? null) : null);
    });
  });
}

/** Tell the pairing room that a local toggle moved; the server re-reads truth. */
export function announcePrivacyChange(pairingId: string): void {
  socket?.emit('privacy:changed', { pairingId });
}

/** Report indicator state so the guardian dashboard can show it too. */
export function reportIndicator(
  pairingId: string,
  kind: 'CAMERA' | 'MICROPHONE',
  active: boolean,
): void {
  socket?.emit('indicator:state', { pairingId, kind, active });
}

export function disconnectSocket(): void {
  socket?.removeAllListeners();
  socket?.disconnect();
  socket = null;
}

export { shouldShareLocation };
