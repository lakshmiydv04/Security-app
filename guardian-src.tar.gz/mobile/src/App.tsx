/**
 * App root and orchestration.
 *
 * Deliberately holds the wiring that must never be a screen's responsibility:
 * the indicator sync, the socket subscription and the location loop all live
 * here so that no screen can neglect them, and the indicator banner is
 * rendered above everything so no screen can cover it.
 */

import React, { useCallback, useEffect, useRef, useState } from 'react';
import { StatusBar, StyleSheet, View } from 'react-native';
import { Provider } from 'react-redux';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { store, useAppDispatch, useAppSelector } from './store';
import { configureApi } from './api/client';
import { locationApi, pairingApi, privacyApi } from './api/endpoints';
import { loadTokens, saveTokens } from './store/secureTokens';
import { restored, tokensRotated } from './store/authSlice';
import {
  connectionsFailed,
  connectionsLoading,
  pairingsLoaded,
  snapshotReceived,
} from './store/connectionSlice';
import { streamStarted, streamStopped } from './store/streamSlice';
import { shouldShareLocation } from './store/reconcile';
import {
  connectSocket,
  disconnectSocket,
  reportIndicator,
  subscribeToPairing,
} from './realtime/socket';
import { createIndicatorSync } from './realtime/indicatorSync';
import { ensureLocationPermission, getCurrentPosition } from './location';
import { LOCATION_PING_INTERVAL_MS } from './config';
import { SignInScreen } from './screens/SignInScreen';
import { PairingScreen } from './screens/PairingScreen';
import { PrivacyControlScreen } from './screens/PrivacyControlScreen';
import { StreamIndicatorBanner } from './components/StreamIndicatorBanner';
import { theme } from './theme';

function Root(): React.JSX.Element {
  const dispatch = useAppDispatch();
  const authStatus = useAppSelector((s) => s.auth.status);
  const accessToken = useAppSelector((s) => s.auth.tokens?.accessToken);
  const pairings = useAppSelector((s) => s.connection.pairings);
  const [showPairing, setShowPairing] = useState(false);

  // The API client reads tokens through these, so a rotation performed inside
  // a request is reflected in the store and persisted without the caller
  // knowing anything happened.
  useEffect(() => {
    configureApi(
      () => store.getState().auth.tokens,
      async (tokens) => {
        await saveTokens(tokens);
        store.dispatch(tokensRotated(tokens));
      },
    );
  }, []);

  useEffect(() => {
    void (async () => {
      const tokens = await loadTokens();
      dispatch(restored({ tokens }));
    })();
  }, [dispatch]);

  const refreshConnections = useCallback(async () => {
    dispatch(connectionsLoading());
    try {
      const { pairings: list } = await pairingApi.list();
      dispatch(pairingsLoaded(list));

      await Promise.all(
        list.map(async (p) => {
          try {
            const snapshot = await privacyApi.get(p.id);
            dispatch(snapshotReceived({ pairingId: p.id, snapshot }));
            await subscribeToPairing(p.id);
          } catch {
            /* one unreadable connection must not blank the whole screen */
          }
        }),
      );
    } catch {
      dispatch(connectionsFailed('Could not load your connections.'));
    }
  }, [dispatch]);

  // Keep the Android foreground notification in step with real stream state.
  useEffect(() => {
    const sync = createIndicatorSync(() => store.getState());
    sync();
    return store.subscribe(sync);
  }, []);

  // Socket lifecycle.
  useEffect(() => {
    if (authStatus !== 'signedIn' || !accessToken) {
      disconnectSocket();
      return;
    }

    connectSocket(accessToken, {
      onConnectionChange: (connected) => {
        if (connected) void refreshConnections();
      },
      onPrivacyState: (pairingId, snapshot) => {
        dispatch(snapshotReceived({ pairingId, snapshot }));
      },
      getSnapshot: (pairingId) => store.getState().connection.snapshots[pairingId] ?? null,
      onSensorCommand: (command) => {
        // Indicator first, capture second. If capture is ever wired in below,
        // it must stay in this order - a stream that starts before the banner
        // is up is exactly the failure this product exists to prevent.
        dispatch(streamStarted({ pairingId: command.pairingId, kind: command.kind }));
        reportIndicator(command.pairingId, command.kind, true);

        // TODO(media): attach WebRTC capture here. Until then the indicator
        // is exercised end to end but no media is sent, which is the honest
        // state of this build rather than a silent no-op.
        setTimeout(() => {
          dispatch(streamStopped({ pairingId: command.pairingId, kind: command.kind }));
          reportIndicator(command.pairingId, command.kind, false);
        }, 15_000);
      },
      onLocalRefusal: (command) => {
        reportIndicator(command.pairingId, command.kind, false);
      },
    });

    void refreshConnections();
    return () => disconnectSocket();
  }, [authStatus, accessToken, dispatch, refreshConnections]);

  // Location loop. Gated per pairing by the same rule the server enforces.
  const permissionAsked = useRef(false);
  useEffect(() => {
    if (authStatus !== 'signedIn') return;

    let cancelled = false;

    const tick = async (): Promise<void> => {
      const state = store.getState();
      const sharing = state.connection.pairings.filter((p) =>
        shouldShareLocation(state.connection.snapshots[p.id] ?? null),
      );
      if (sharing.length === 0) return;

      if (!permissionAsked.current) {
        permissionAsked.current = true;
        if (!(await ensureLocationPermission())) return;
      }

      const fix = await getCurrentPosition();
      if (!fix || cancelled) return;

      await Promise.all(
        sharing.map((p) =>
          locationApi.push(p.id, fix).catch(() => {
            // A refusal here means the server's view is stricter than ours;
            // the next privacy:state event will correct the UI.
          }),
        ),
      );
    };

    void tick();
    const id = setInterval(() => void tick(), LOCATION_PING_INTERVAL_MS);
    return () => {
      cancelled = true;
      clearInterval(id);
    };
  }, [authStatus]);

  const content = (): React.JSX.Element => {
    if (authStatus === 'restoring') return <View style={styles.flex} />;
    if (authStatus === 'signedOut') return <SignInScreen />;
    if (showPairing || pairings.length === 0) {
      return (
        <PairingScreen
          onPaired={() => {
            setShowPairing(false);
            void refreshConnections();
          }}
        />
      );
    }
    return (
      <PrivacyControlScreen
        onRefresh={refreshConnections}
        onAddConnection={() => setShowPairing(true)}
      />
    );
  };

  return (
    <View style={styles.flex}>
      <StatusBar barStyle="light-content" backgroundColor={theme.color.bg} />
      {/* Above the screen stack: no route can cover it. */}
      <StreamIndicatorBanner />
      {content()}
    </View>
  );
}

export default function App(): React.JSX.Element {
  return (
    <Provider store={store}>
      <SafeAreaProvider>
        <Root />
      </SafeAreaProvider>
    </Provider>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: theme.color.bg },
});
